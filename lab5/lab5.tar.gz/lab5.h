//  =============== BEGIN ASSESSMENT HEADER ================
/// @file lab5.h
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date May 12, 2015

//  ================== END ASSESSMENT HEADER ===============
#ifndef LAB5_H
#define LAB5_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>

using namespace std;

#define nil 0

// #define Value int
template < typename Value >
class BST {

	class Node {  //  binary tree node
	public:
		
        Value value;
		Node* left;
        Node* right;
        
        bool selected;

        Node( const Value v = Value() )
            : value(v), left(nil), right(nil), selected(false)
            
		{}
		Value& content()  { return value; }
		bool isInternal() { return left != nil && right != nil; }
		bool isExternal() { return left != nil || right != nil; }
		bool isLeaf()     { return left == nil && right == nil; }
		
		
		int height() {
            // returns the height of the subtree rooted at this node
            //this is the node we are at

            if (this == nil || isLeaf() == true)
				return 0;
			return 1+ max(left->height(), right->height());
			
		}
        
        int size() {
            // returns the size of the subtree rooted at this node,
            
            int tSize =1;
 
            if (left != NULL) tSize += left->size();  
            if (right != NULL) tSize += right->size();
            
            return tSize;
        }
        
       //returns true if found
       
        bool search(Value x) {
		
            if (this == nil){
                return false;}
            else if (x == value){
			    return true;}
		    else if (x < value){ //value is basically like current
		        return (left->search(x));}
		    else{
		        return (right->search(x));}	
        }
		
        
		
	}; // Node


	// const Node* nil;  // later nil will point to a sentinel node.
	int count;
	Node* root;
	

public:

    int size() {
        // size of the overall tree.
 
        int tSize =1;

        if (root->left != NULL) tSize += root->left->size(); 
        if (root->right != NULL) tSize += root->right->size();
            
        //cout << "height = " << root->height() << endl;
        return tSize;
        
    }
    
    bool empty() { return size() == 0; }
    
    void print_node( const Node* n ) {
        // Print the node’s value.

        
        cout << n->value;
    }


    bool search ( Value x ) {
        // search for a Value in the BST and return true iff it was found.

        if (root == nil){
            return false;}
        else if (x == root->value){
			return true;}
		else if (x < root->value){
		    return (root->left->search(x));}
		else {
		    return (root->right->search(x));}
    }
    
    void preorder()const {
        // Traverse and print the tree one Value per line in preorder.

        preorderTraverse(root);
    }
    
    void postorder()const {
        // Traverse and print the tree one Value per line in postorder.

        postorderTraverse(root);
    }
    
    void inorder()const {
        // Traverse and print the tree one Value per line in inorder.

        inorderTraverse(root);
    }
    
    
    
    Value& operator[] (int n) {
        // returns reference to the value field of the n-th Node.
        
        Node *temp = findNode(n, root);
        
        return temp->value;
    
    }
    
 
    Node* findNode(int &n, Node* subTree)
    {
        
        if(subTree != nil){
            Node *left = findNode(n, subTree->left);
            
            if(left != nil){ 
                return left; }
        
            if(n == 0){ 
                return subTree; }
            
            n--;
        
            Node *right = findNode(n, subTree->right);
        
            if(right != nil){ 
                return right; }
        }
        return nil;
    
    }
    

    
    void preorderTraverse(Node* subTree)const
	{
		if(subTree == nil)
		{
			return;
		}
		cout << subTree->value << ' ';
		preorderTraverse(subTree->left);
		preorderTraverse(subTree->right);
	}
	
	void postorderTraverse(Node* subTree) const
	{
		if(subTree == nil)
		{
			return;
		}
		postorderTraverse(subTree->left);
		postorderTraverse(subTree->right);
		cout << subTree->value << ' ';
	}
	
	void inorderTraverse(Node* subTree)const
	{
		if(subTree == nil)
	    {
			return;
	    }
		inorderTraverse(subTree->left);
		cout << subTree->value << ' ';
		inorderTraverse(subTree->right);
	}
	
		//find the smallest vertex cover of the tree
	// root level
	void minCover()
	{
        DFS(root->left);
        DFS(root->right);
	}
	
	
    //select nodes that are part of vertex cover
    void DFS(Node* subTree) 
    {
        if (subTree==nil || subTree->isLeaf()){
            return; }
            

        DFS(subTree->left);
        DFS(subTree->right);
        
        
        if (subTree->isInternal())         // part of vertex cover if the node has both edges
            subTree->selected = true;
        else if ((subTree->left != nil && !subTree->left->selected ) ||  // node has 1 edge, part of vertex cover
                (subTree->right != nil && !subTree->right->selected))    // if child is not covered
                subTree->selected = true; 
        else
            subTree->selected = false;
            
        //cout << "value " << subTree -> value << endl;
        
        
    }
    
	
	// display the smallest cover and the size of vertex cover
	// root level
	void displayMinCover()
	{
        int Size = 0;
        Size += displayMinCoverSub(root->left);
        Size += displayMinCoverSub(root->right);
        cout << endl;
        cout << Size << endl;
	    
	}
	
	// return size display the nodes of vertex cover
	int displayMinCoverSub(Node* subTree)
	{
	    int Size=0;
	   
	    if (subTree==nil){
            return 0;} 

        if (subTree->selected== true){
            Size = 1;}

        
        Size += displayMinCoverSub(subTree->left);
		if (subTree->selected== true)
		{
		    cout << subTree->value << ' ';
		}
		Size += displayMinCoverSub(subTree->right);
        return Size;
	}  
	
	
	// find and display path from root to leaf
	// root level
    void findSumRoot (int sum)
    {
        const int ARRAY_SIZE = 1000;
        int buffer[ARRAY_SIZE];
        //int *buffer = new int[ARRAY_SIZE];

        findSumPath(root, sum, buffer);
        
    }


    // find and display path from root to leaf which the sum of the node values
    // on the path is equal to a particular ‘sum’ taken as input
    // print 0 if no path is found
    void findSumPath (Node* n, int sum, int buffer[])
    {

        buffer[0] = n->value;
        
        bool found_l = findSumLeaf (n->left, sum, n->value, 1, buffer);
        bool found_r = findSumLeaf (n->right, sum, n->value, 1, buffer);
        
        if (!found_l && !found_r){
            cout << '0' << endl;}
        
    }


    // find and display path from root to leaf which the sum of the node values
    // on the path is equal to a particular ‘sum’ taken as input
    bool findSumLeaf (Node* n, int sum, int curr_sum, int index, int buffer[])
    {

        bool found = false;
        
        // base case
        if (n == NULL) {
            return false;}
        
    
        buffer[index] = n->value;               // store node value
        curr_sum = curr_sum + (n->value);       // update curr_sum 
        //cout <<  "index, value, curr_sum " << index << " " << (n->value) << " " << curr_sum << endl;       //          
        
        if (n->isLeaf()) {                      // if node is leaf, check if curr_sum=sum
			if (curr_sum == sum)                // print if curr_sum=sum
		    {
				for (int i=index; i >= 0; i--)
                {
                    cout  << buffer[i] << ' '; 
                }
                cout  << endl;
				found = true;
			}
        }
				

        bool found_l = findSumLeaf( n->left, sum, curr_sum, index+1, buffer );
        bool found_r = findSumLeaf( n->right, sum, curr_sum, index+1, buffer );
        
        return (found_l || found_r || found) ;
        
    }
 
    
    //find the vertical sum of nodes that lie on same vertical line in tree
    //root level
    void vertSumRoot()
    {
        map < int,int > m;
        vertSum(root,0,m);  
        
        // print sum stored in m
        map< int,int > :: iterator itr;
        for (itr=m.begin(); itr!=m.end(); itr++)
        {
            cout << itr->second << " ";
        }
        cout << endl;
    }

    //find the vertical sum of nodes that lie on same vertical line in tree
    void vertSum(Node* node, int hd, map<int, int>& m)
    {
        
       // Base case
        if (node == NULL){
            return;}
 
        // add map value to node value
        int sum = m.find(hd)->second + node->value;
        //remove the current value from map
        m.erase (hd);
        //store sum back in map 'm'
        m.insert ( pair<int,int>(hd,sum) );

        vertSum(node->left, hd-1, m);
        vertSum(node->right, hd+1, m);        
        
    }
	
	
    
    BST() : count(0), root(nil) {}
    
    
    
    void insert( Value X ) { root = insert( X, root ); }
    
    Node* insert( Value X, Node* T ) {
        // The normal binary-tree insertion procedure ...
        if ( T == nil ) {
            T = new Node( X );              // the only place that T gets updated.
        } else if ( X < T->value ) {
            T->left = insert( X, T->left );
        } else if ( X > T->value ) {
            T->right = insert( X, T->right );
        } else {
            T->value = X;
        }
        
        
        // later, rebalancing code will be installed here
        
        return T;
    }
    
    void remove( Value X ) { root = remove( X, root ); }
    
    Node* remove( Value X, Node*& T ) {
        // The normal binary-tree removal procedure ...
        // Weiss’s code is faster but way more intricate.
        if ( T != nil ) {
            if ( X > T->value ) {
                T->right = remove( X, T->right );
                
            } else if ( X < T->value ) {
                T->left = remove( X, T->left );
                
            } else {                                        // X == T->value
                if ( T->right != nil ) {
                    Node* x = T->right;
                    while ( x->left != nil ) x = x->left;
                    T->value = x->value;                    // successor’s value
                    T->right = remove( T->value, T->right );
                    
                } else if ( T->left != nil ) {
                    Node* x = T->left;
                    while ( x->right != nil ) x = x->right;
                    T->value = x->value; // predecessor’s value
                    T->left = remove( T->value, T->left );
                    
                } else {                                    // *T is external
                    delete T;
                    T = nil;                                // the only updating of T
                }
            }
        }
    
    // later, rebalancing code will be installed here
    
    return T;
    }
    

    void okay( ) { okay( root ); }
    void okay( Node* T ) {
        // diagnostic code can be installed here
        return;
    }
}; // BST


#endif