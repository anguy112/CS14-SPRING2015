//  =============== BEGIN ASSESSMENT HEADER ================
/// @file main.cc
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date May 12, 2015

//  ================== END ASSESSMENT HEADER ===============
#include <iostream>
using namespace std;
#include "lab5.h"

int main()
{




	cout << "Testcase 1" << endl;
		BST<int> t1;
		int data [10] ={50,20,10,40,35,45,60,70};
		
		for(int i = 0; i < 8; ++ i ) {
	
			t1.insert( data[i] );
		}
		
		
		cout << "Part 1" << endl;
		t1.minCover();
		t1.displayMinCover();
		
		cout << "Part 2" << endl;
		
		t1.findSumRoot(80);
	
		cout << "Part 3" << endl;	
		t1.vertSumRoot();
		
		
		
		cout << "Testcase 2" << endl;
	
		BST<int> t2;
		int data2 [20] ={15,7,5,21,30,9,16,3,4,13,25,20,35,8,2,22,23,14,6,12};
	
	
		for(int i = 0; i < 20; ++ i ) {
	
			t2.insert( data2[i] );
	
		}
		
		//t2.inorder();
		//cout << endl;
		
		cout << "Part 1" << endl;
		t2.minCover();
		t2.displayMinCover();
		cout << "Part 2" << endl;	
		t2.findSumRoot(32);
		/*
		t2.findSumRoot(34);
		t2.findSumRoot(33);
		t2.findSumRoot(23);
		t2.findSumRoot(72);
		t2.findSumRoot(101);
		t2.findSumRoot(136);
		*/
	
		cout << "Part 3" << endl;	
		t2.vertSumRoot();
	
		

		cout << "Testcase 3" << endl;
		BST<int> t3;
		int data3 [10] ={50,20,10,60,70};
		
		for(int i = 0; i < 5; ++ i ) {
	
			t3.insert( data3[i] );
		}
		
		cout << "Part 1" << endl;
		t3.minCover();
		t3.displayMinCover();
		cout << "Part 2" << endl;	
		t3.findSumRoot(80);
		//t3.findSumRoot(180);
		//t3.findSumRoot(70);
		//t3.findSumRoot(50);
	
		cout << "Part 3" << endl;	
		t3.vertSumRoot();

		
		return 0;
	

}