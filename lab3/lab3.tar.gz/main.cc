//  =============== BEGIN ASSESSMENT HEADER ================
/// @file main.cc
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date April 27, 2015


//  ================== END ASSESSMENT HEADER ===============
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <stack>
#include "lab3.h"





int main()
{

    
    char data1 [20] ={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q'};
    char data2 [20] ={'0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6'};
    char data3 [20] ={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q'};

    int arraySize = 20;
    int partition = 10;
    
    cout << "---------------------------------" << endl;
    cout << "TwoStackFixed: char type" << endl;
    cout << "---------------------------------" << endl << endl;
    
    cout << "---------------------------------" << endl;
    cout << "PUSH Stack1" << endl;
    cout << "---------------------------------" << endl;
    
    TwoStackFixed<char> L1(arraySize, partition);    

    for (int i=0; i< 10; i++)
    {
        L1.pushStack1(data1[i]); 
    }

    cout << "---------------------------" << endl;
    cout << "POP Stack 1" << endl;
    cout << "---------------------------" << endl;

    
    for (int i=0; i< 7; i++)
    {
        cout << "Stack 1 value = " << L1.popStack1() << endl;
        //L1.pushStack1(data3[i]);
    }
    
    cout << "---------------------------------" << endl;
    cout << "PUSH Stack1" << endl;
    cout << "---------------------------------" << endl;    
    
    for (int i=0; i< 10; i++)
    {
        L1.pushStack1(data3[i]);
    }


    cout << "---------------------------------" << endl;
    cout << "PUSH Stack2" << endl;
    cout << "---------------------------------" << endl;
    

    for (int i=0; i< 10; i++)
    {
        L1.pushStack2(data2[i]); 
    }

    cout << "---------------------------" << endl;
    cout << "POP Stack 2" << endl;
    cout << "---------------------------" << endl;

    
    for (int i=0; i< 5; i++)
    {
        cout << "Stack 2 value = " << L1.popStack2() << endl;

    }
    
    cout << "---------------------------------" << endl;
    cout << "PUSH Stack2" << endl;
    cout << "---------------------------------" << endl;    
    
    for (int i=0; i< 10; i++)
    {
        L1.pushStack2(data3[i]);
    }
    
    
    cout << "---------------------------" << endl;
    cout << "POP Stack 1 Entirely" << endl;
    cout << "---------------------------" << endl;

    
    for (int i=0; i< 11; i++)
    {
        cout << "Stack 1 value = " << L1.popStack1() << endl;

    }    
    
    cout << "---------------------------" << endl;
    cout << "POP Stack 2 Entirely" << endl;
    cout << "---------------------------" << endl;

    
    for (int i=0; i< 11; i++)
    {
        cout << "Stack 2 value = " << L1.popStack2() << endl;

    }       
  
 
  
    cout << "---------------------------------" << endl;
    cout << "TwoStackFixed: integer type" << endl;
    cout << "---------------------------------" << endl << endl; 
    
    int data4 [20] ={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19};
    int data5 [20] ={100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119}; 
    
    TwoStackFixed<int> L2(arraySize, partition);  


    cout << "---------------------------------" << endl;
    cout << "PUSH Stack1 and Stack2" << endl;
    cout << "---------------------------------" << endl;    
    
    for (int i=0; i< 10; i++)
    {
        L2.pushStack1(data4[i]);
        L2.pushStack2(data5[i]);
    }
    
    cout << "---------------------------" << endl;
    cout << "POP Stack 1 and Stack2 Entirely" << endl;
    cout << "---------------------------" << endl;

    
    for (int i=0; i< 11; i++)
    {
        cout << "Stack 1 value = " << L2.popStack1() << endl;
        cout << "Stack 2 value = " << L2.popStack2() << endl;

    }   
    

    cout << "---------------------------------" << endl;
    cout << "TwoStackOptimal: integer type" << endl;
    cout << "---------------------------------" << endl << endl; 
    
    TwoStackOptimal<int> L3(arraySize); 
    
    cout << "---------------------------------" << endl;
    cout << "PUSH Stack1" << endl;
    cout << "---------------------------------" << endl;    
    
    for (int i=0; i< 15; i++)
    {
        L3.pushFlexStack1(data4[i]);
    }
    
    cout << "---------------------------------" << endl;
    cout << "PUSH Stack2" << endl;
    cout << "---------------------------------" << endl;    
    
    for (int i=0; i< 7; i++)
    {
        L3.pushFlexStack2(data5[i]);
    }
    
    cout << "---------------------------------" << endl;
    cout << "Display array" << endl;
    cout << "---------------------------------" << endl;   
    
    L3.display();
    
    
    
    cout << "---------------------------" << endl;
    cout << "POP Stack 1 and Stack2 Entirely" << endl;
    cout << "---------------------------" << endl;

    
    for (int i=0; i< 17; i++)
    {
        cout << "Stack 1 value = " << L3.popFlexStack1() << endl;
    } 
    
    for (int i=0; i< 8; i++)
    {
        cout << "Stack 2 value = " << L3.popFlexStack2() << endl;
    } 
    
    
    L3.display();
    
    
    cout << "---------------------------" << endl;
    cout << "Tower of Ha Noi Type = integer" << endl;    
    cout << "---------------------------" << endl;
    


    int stackData1 [10] ={1,2,3,4,5,6,7,8,9,10};
    stack<int> A;
    stack<int> B; 
    stack<int> C;


    int diskNumber = 5;
    
    for (int i=0; i < diskNumber ; i++)
    {
        A.push(stackData1[i]);
    }
    
   cout << "Stack A size = " << A.size() << " Stack B size = " << B.size() <<
   " Stack C size = " << C.size()<< endl;
    
    showTowerStates(diskNumber, A, B, C);
    
    cout << "Stack A size = " << A.size() << " Stack B size = " << B.size() <<
   " Stack C size = " << C.size()<< endl;
    

    cout << "Display Destination Stack C" << endl;    
    
    for (int i=0; i < diskNumber ; i++)
    {
        cout << C.top() << endl;
        C.pop();

    }



    cout << "---------------------------" << endl;
    cout << "Tower of Ha Noi Type = char" << endl;    
    cout << "---------------------------" << endl;

    char stackData2 [10] ={'a','b','c','d','e','f','g','h','i','j'};
    stack<char> AA;
    stack<char> BB; 
    stack<char> CC;
    
    
    diskNumber = 3;
    
    for (int i=0; i < diskNumber ; i++)
    {
        AA.push(stackData2[i]);
    }
    
    
    
    showTowerStates(diskNumber, AA, BB, CC);
    

    cout << "Display Destination Stack C" << endl;    
    
    for (int i=0; i < diskNumber ; i++)
    {
        cout << CC.top() << endl;
        CC.pop();

    }


    return 0;
}