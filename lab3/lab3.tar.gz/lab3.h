//  =============== BEGIN ASSESSMENT HEADER ================
/// @file lab3.h
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date April 27, 2015
//  ================== END ASSESSMENT HEADER ===============

#ifndef LAB3_H
#define LAB3_H

#include <iostream>
#include <stack>

using namespace std;


template <typename T>
class TwoStackFixed
{
   private:
   T *arr1;
   int top1;
   int top2;
   int size1;
   int partition1;

   public:
   TwoStackFixed();
   TwoStackFixed(int size, int maxtop);
   ~TwoStackFixed(); 
   
   void pushStack1(T value);
   void pushStack2(T value);
   T popStack1();
   T popStack2();
   bool isFullStack1();
   bool isFullStack2();
   bool isEmptyStack1();
   bool isEmptyStack2();
   void display();
   void Stack1display();
   void Stack2display();

};

template <typename T>
class TwoStackOptimal
{
    private:
      T *arr2;
      int top1;
      int top2;
      int size2;
    
    public:
    TwoStackOptimal();
    TwoStackOptimal(int size);
    ~TwoStackOptimal();
    
    void pushFlexStack1(T value);
    void pushFlexStack2(T value);
    T popFlexStack1();
    T popFlexStack2();
    bool isFullStack1();
    bool isFullStack2();
    bool isEmptyStack1();
    bool isEmptyStack2();
    void display(); 
    void Stack1display();
    void Stack2display();
};


template <typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C);



template <typename T>
TwoStackFixed<T>::TwoStackFixed()
{
   size1 = 0;
   partition1 = 0;
   top1 = -1;
   top2 = 0;
}

template <typename T>
TwoStackFixed<T>::TwoStackFixed(int size, int maxtop)
{
   arr1 = new T[size];
   //int arr1[size];
    size1 = size;
   partition1 = maxtop;
   
   top1 = -1;
   top2 = size;
}

template<typename T>
TwoStackFixed<T>::~TwoStackFixed()
{
   delete [] arr1;
}


template <typename T>
void TwoStackFixed<T>::pushStack1(T value)
{
   
   
   if(isFullStack1() == true)
   {
      cout << "Error, Stack 1 is full" << endl;
      return;
   }
   
   else
   {
      
      ++top1;
      arr1[top1] = value;
      Stack1display();
   }
}


template <typename T>
void TwoStackFixed<T>::pushStack2(T value)
{
   

   if(isFullStack2() == true)
   {
      cout << "Error, Stack 2 is full" << endl;
      return;
   }
   
   
   else
   {
      --top2;
      arr1[top2] = value;
      Stack2display();
   }
   
}

template <typename T>
T TwoStackFixed<T>::popStack1()
{

   if(isEmptyStack1() == true)
   {
      cout << "Error, Stack1 is empty" << endl;
      return 0;
   }
   
   else
   {
      T poppedVal1 = arr1[top1];
      //arr1[top1] = NULL;
      --top1;
      return poppedVal1;
      //do something that will shift all of the elements;
      //i think he said dont shift elements over the partition;
      
   }
}


template <typename T>
T TwoStackFixed<T>::popStack2()
{
   if(isEmptyStack2() == true)
   {
    cout << "Error, Stack2 is empty" << endl;
    return 0;
   }
   
   
   else
   {
      T poppedVal2 = arr1[top2];
      //arr1[top2] = NULL;
      ++top2;
      return poppedVal2;
   }
   
}

template <typename T>
bool TwoStackFixed<T>::isFullStack1()
{
   if(top1 >= partition1-1)
   {
      return true;
   }
   
   else
   {
      return false;
   }
   
}

template <typename T>
bool TwoStackFixed<T>::isFullStack2()
{
   if(top2 <= partition1)
   {
      return true;
   }
   
   else
   {
      return false;
   }
  
   
}

template <typename T>
bool TwoStackFixed<T>::isEmptyStack1()
{
   if(top1 == -1) 
   {
      return true;
   }
   
   else
   {
      return false;
   }
}

template <typename T>
bool TwoStackFixed<T>::isEmptyStack2()
{
   
  if(top2 == size1) 
  {
     return true;
  }
  
  else
  {
     return false;
  }
   
}

template <typename T>
void TwoStackFixed<T>::display()
{
   if(isEmptyStack1() && isEmptyStack2())
   {
      cout << "Whole array is empty" << endl;
   }
   
   for(int i = 0; i < size1; i++)
   {
      cout << arr1[i] << " ";
   }
   
   cout << endl;
}



template <typename T>
void TwoStackFixed<T>::Stack1display()
{
   if(isEmptyStack1())
   {
      cout << "Stack1 is empty" << endl;
   }
   
   for(int i = top1; i >= 0; i--)
   {
      cout << arr1[i] << " ";
   }
   
   cout << endl;
}

template <typename T>
void TwoStackFixed<T>::Stack2display()
{
   if(isEmptyStack2())
   {
      cout << "Stack2 is empty" << endl;
   }
   
   for(int i = top2; i < size1; i++)
   {
      cout << arr1[i] << " ";
   }
   
   cout << endl;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//part 2
template <typename T>
TwoStackOptimal<T>::TwoStackOptimal()
{
   size2 = 0;
   top1 = -1;
   top2 = 0;
}

template <typename T>
TwoStackOptimal<T>::TwoStackOptimal(int size)
{
   arr2 = new T[size];
   size2 = size;
   
   top1 = -1;
   top2 = size;
}

template <typename T>
TwoStackOptimal<T>::~TwoStackOptimal()
{
delete []arr2;
}


template <typename T>
void TwoStackOptimal<T>::pushFlexStack1(T value)
{
   
   if(isFullStack1() == true)
   {
      cout << "Error, stack1 is full " << endl;
      return;
   }
   
   else
   {
      ++top1;
      arr2[top1] = value;
      Stack1display();
   }
}

template <typename T>
void TwoStackOptimal<T>::pushFlexStack2(T value)
{

   if(isFullStack2() == true)
   {
      cout << "Error, stack2 is full " << endl;
      return;
   }
   
   else
   {
      --top2;
      arr2[top2] = value;
      Stack2display();
   }
   
}


template <typename T>
T TwoStackOptimal<T>::popFlexStack1()
{
   
   
   if(isEmptyStack1() == true)
   {
      cout << "Error, stack1 is empty " << endl;
      return 0;
   }
   
   else
   {
      T poppedVal3 = arr2[top1];
      //arr2[top1] = NULL;
      --top1;
      //cout << poppedVal3 << endl;
      return poppedVal3;
   }
   
   
}

template <typename T>
T TwoStackOptimal<T>::popFlexStack2()
{
   
   if(isEmptyStack2() == true)
   {
      cout << "Error, stack1 is empty " << endl;
      return 0;
   }
   
   else
   {
      T poppedVal4 = arr2[top2];
      //arr2[top2] = NULL;
      ++top2;
      //cout << poppedVal4 << endl;
      return poppedVal4;
   }
   
   
}

template <typename T>
bool TwoStackOptimal<T>::isFullStack1()
{
   if(top1 >= top2 -1)
   {
      return true;
   }
   
   else
   {
      return false;
   }
}

template <typename T>
bool TwoStackOptimal<T>::isFullStack2()
{
   if(top2 <= top1 + 1)
   {
      return true;
   }
   
   else
   {
      return false;
   }
   
}

template <typename T>
bool TwoStackOptimal<T>::isEmptyStack1()
{
   if(top1 == -1) 
   {
      return true;
   }
   
   else
   {
      return false;
   }
}

template <typename T>
bool TwoStackOptimal<T>::isEmptyStack2()
{
   if(top2 == size2) 
   {
      return true;
   }
   else
   {
      return false;
   }
}

template <typename T>
void TwoStackOptimal<T>::display()
{
   if(isEmptyStack1() && isEmptyStack2())
   {
      cout << "Whole array is empty" << endl;
   }
   
   for(int i = 0; i < size2; i++)
   {
      cout << arr2[i] << " ";
   }
   
   cout << endl;
}



template <typename T>
void TwoStackOptimal<T>::Stack1display()
{
   if(isEmptyStack1())
   {
      cout << "Stack1 is empty" << endl;
   }
   
   for(int i = top1; i >= 0; i--)
   {
      cout << arr2[i] << " ";
   }
   
   cout << endl;
}

template <typename T>
void TwoStackOptimal<T>::Stack2display()
{
   if(isEmptyStack2())
   {
      cout << "Stack2 is empty" << endl;
   }
   
   for(int i = top2; i < size2; i++)
   {
      cout << arr2[i] << " ";
   }
   
   cout << endl;
}
//-------------------------------------------------------------------
//part3
//-------------------------------------------------------------------


// Move from peg A to peg C
template <typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C)
{
 
   int ID1;
   int ID2;
   int ID3;
   char src;
   char dest;

   
   // first call: set ID to each peg
   if (A.size()==n && B.size()==0 && C.size()==0)
   {
      A.push('A');
      B.push('B');
      C.push('C');
   }
   

   if (n==1)                     // base case
   {
      // pop ID before processing
      ID1 = A.top(); 
      ID2 = B.top();
      ID3 = C.top();
      
      A.pop();
      B.pop();
      C.pop();
      
      // generate src and dest based on ID in each peg
      src = ID1;
      dest = ID3;
      
      // move value from A to C     
      T  value = A.top();
         A.pop();
         C.push(value);

      cout << "Moved " << value << " from peg " << src << " to " << dest << endl;
      
      // push ID back into stacks except when it's the last call

      if (A.size()==0 && B.size()==0)  // last call, don't put ID back in the stack
      {
         return;
      }
      else 
      {
         A.push(ID1);
         B.push(ID2);
         C.push(ID3);
         return;
      }

   }
   else                                // recursive call
   {
      showTowerStates(n-1, A, C, B);
      showTowerStates(1,   A, B, C);
      showTowerStates(n-1, B, A, C);
   }
   
}


#endif