//  =============== BEGIN ASSESSMENT HEADER ================
/// @file main.cc
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date May 4, 2015


//  ================== END ASSESSMENT HEADER ===============
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <stack>
#include "lab4.h"


int main(int argc, char** argv) {

    if (argc < 2) {     //outputs an error when not sufficient parameters
        cout << "invalid parameters" << endl;
        exit(1);
    }


    int k;
    string value = argv[1];
    
    
    istringstream ss(value);
    ss >> k;
    
    cout << "Pre-Order" << endl;
    PreOrderRoot(k);
    
    cout << "Post-Order" << endl;
    PostOrderRoot(k);
    
    
    cout << "Sorted" << endl;
    SortedOrderRoot(k);



    return 0;
}