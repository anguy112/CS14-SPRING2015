//  =============== BEGIN ASSESSMENT HEADER ================
/// @file lab4.h
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date May 4, 2015
//  ================== END ASSESSMENT HEADER ===============

#ifndef LAB4_H
#define LAB4_H

#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

typedef pair<int,int> Entry;

class priority_queue {
public:
    vector<Entry> entries;
    Entry& front() { return entries.back(); }
    void pop() { entries.pop_back(); }
    void push( Entry e ) 
    {
        entries.push_back( e );
    
        for ( int i = entries.size()-1; i != 0;--i )
        {
            if ((get<0>(entries[i]) + get<1>(entries[i])) > (get<0>(entries[i-1]) + get<1>(entries[i-1])))
            {
                swap(entries[i], entries[i-1]);
            }
            
            else if((get<0>(entries[i]) + get<1>(entries[i])) == (get<0>(entries[i-1]) + get<1>(entries[i-1])))
            {
                if(get<0>(entries[i]) > get<0>(entries[i-1]))
                {
                    swap(entries[i], entries[i-1]);
                }
            }
           

    
        }
    }
};

void PreOrderRoot(int k);
void PostOrderRoot(int k);
void SortedOrderRoot(int k);

void PreOrder(int m,int n,int k);
void PostOrder(int m, int n, int k);
void SortedOrder(int m, int n, int k, priority_queue &list);



void PreOrderRoot(int k)
{
    //first left node
    PreOrder(2,1,k);
    
    //first right node
    PreOrder(3,1,k);
    
}



void PostOrderRoot(int k)
{
    //first left node
    PostOrder(2,1,k);
    
    //first right node
    PostOrder(3,1,k);
    
}

//the root has no children, all other nodes have 3 children
// A node with numbers (m,n) has children(2m − n, m), (2m + n, m) and (m + 2n, n).
void PreOrder(int m, int n, int k)
{
    //left to right going down
    if(m+n >= k) //base case
    {
        return;
    }
    
    cout <<  m  << " " << n << endl;
    
    //left child
    int a1 = ((2*m)-n);
    int a2 = m;
    
    
    PreOrder(a1,a2,k);
    
    //middle child
    int b1 = ((2*m)+n);
    int b2 = m;

    
    PreOrder(b1,b2,k);
    
    //right child
    int c1 = (m+(2*n));
    int c2 = n;
    
    PreOrder(c1,c2,k);
    
    
}


void PostOrder(int m, int n, int k)
{

    //left to right going down
   if(m+n >= k) //base case
    {
        return;
    }
    
    //left child
    int a1 = ((2*m)-n);
    int a2 = m;
    
    
    PostOrder(a1,a2,k);
    
    //middle child
    int b1 = ((2*m)+n);
    int b2 = m;

    
    PostOrder(b1,b2,k);
    
    //right child
    int c1 = (m+(2*n));
    int c2 = n;
    
    PostOrder(c1,c2,k);
    
    cout <<  m  << " " << n << endl;
    
}





//sorted
//use a priority queue to store the data

void SortedOrderRoot(int k)
{
    
    
    priority_queue list;
    
    //first left node
    SortedOrder(2,1,k,list);
    
    //first right node
    SortedOrder(3,1,k,list);
    
    int size = list.entries.size();
    
    for(int i = 0; i < size; ++i )
    {
        
        pair <int,int> p;
        
        p = list.front();
        
        list.pop();
        
        
        cout << get<0>(p) << " " << get<1>(p) << endl;

    
    }
    
    
    
    
    
}



void SortedOrder(int m, int n, int k, priority_queue &list)
{
    //left to right going down
    if(m+n >= k) //base case
    {
        return;
    }

    pair <int,int> p = make_pair (m,n);
    
    
    list.push(p);
    
    //left child
    int a1 = ((2*m)-n);
    int a2 = m;
    
    
    SortedOrder(a1,a2,k,list);
    
    //middle child
    int b1 = ((2*m)+n);
    int b2 = m;

    
    SortedOrder(b1,b2,k,list);
    
    //right child
    int c1 = (m+(2*n));
    int c2 = n;
    
    SortedOrder(c1,c2,k,list);
    
    
}











#endif