//  =============== BEGIN ASSESSMENT HEADER ================
/// @file lab6.h
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date May 18, 2015

//  ================== END ASSESSMENT HEADER ===============
#ifndef LAB6_H
#define LAB6_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>

#include <utility>  //allows us to use swap

using namespace std;


template<typename L>
void selectionsort(L &l)
{
    //count how many times you move, swap takes 3 moves
    //int swapCount = 0;
    //use begin() to get iterator to beginning of list
    // end() for iterator of end of list
    //use * to dereference the iterator
    for(typename L::iterator  i = l.begin(); i!= l.end(); i++)
    {
        typename L::iterator  smallest = i;
        
        for(typename L::iterator  j = i; j !=l.end(); j++)
        {
            if(*j < *smallest)
            {
                smallest = j;
            }
            //after this smallest will have the smallest value found
        }
        
        if(*smallest < *i)
        {
            swap(*i,*smallest);
            //++swapCount;
        }
    }
    
   // return swapCount;
}



#endif