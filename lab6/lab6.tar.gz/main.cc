//  =============== BEGIN ASSESSMENT HEADER ================
/// @file main.cc
///
/// @author Aaron Nguyen [anguy112@ucr.edu]
/// @SID:861106832
/// @date May 18, 2015

//  ================== END ASSESSMENT HEADER ===============
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <list>
#include <map>
#include "lab6.h"


int main() {
    
    /*******************************
    * test case 1
    *******************************/

	
	
    list<int> l1;
    int p1 [] ={2,4,5,1,8,9};
	
	
	for(int i = 0; i < 6; ++ i ) {
        l1.push_back (p1[i]);
	}
	
	
	cout << "pre:     ";
	for (auto it = l1.begin(); it !=l1.end(); ++ it ) {
         cout << *it << " " ;
	}
	cout << endl;
    
    selectionsort(l1);
    //int swap_cnt = selectionsort(l1);

    cout << "post:    ";
	for (auto it = l1.begin(); it !=l1.end(); ++ it ) {
         cout << *it << " " ;
	}
	cout << endl;
	
	//cout << "move = " << swap_cnt*3 << endl;
    
    /*******************************
    * test case 2
    *******************************/


    list< pair<int,int> > l2;
	int p2[][2] = { {1,2}, {3,-1}, {-1,3}, {0,0}, {2,3}, {1,2}, {1,-2}, {8,10} };
	
	for(int i = 0; i < 8; ++ i ) {
        l2.push_back( pair<int,int>( p2[i][0],p2[i][1] )) ;
	}
	
	cout << "pre:     ";
	for (auto it = l2.begin(); it !=l2.end(); ++ it ) {
         cout << "(" << it->first <<"," << it->second << ") ";
	}
	cout << endl;
	
    selectionsort(l2);
    //swap_cnt = selectionsort(l2);
	
	cout << "post:    ";
	for (auto it = l2.begin(); it !=l2.end(); ++ it ) {
     cout << "(" << it->first <<"," << it->second << ") ";
	}
	cout << endl;
	
	//cout << "move = " << swap_cnt*3 << endl;
    

    /*******************************
    * test case 3
    *******************************/
    
    list< pair<int,int> > l3;
    int p3[][2] = {{10,2}, {-3,-1}, {-8,0}, {1,1}, {1,1}, {0,0}, {10,2}, {5,5}, {5,-5}, {0,0}, {10,2}};
    
    for(int i = 0; i < 11; ++ i ) {
        l3.push_back( pair<int,int>( p3[i][0],p3[i][1] )) ;
	}
	
	cout << "pre:     ";
	for (auto it = l3.begin(); it !=l3.end(); ++ it ) {
         cout << "(" << it->first <<"," << it->second << ") ";
	}
	cout << endl;
	
    selectionsort(l3);
    //swap_cnt = selectionsort(l3);
	
	cout << "post:    ";
	for (auto it = l3.begin(); it !=l3.end(); ++ it ) {
     cout << "(" << it->first <<"," << it->second << ") ";
	}
	cout << endl;
	
	//cout << "move = " << swap_cnt*3 << endl;
    
    
    
    
    /*******************************
    * test case 4
    *******************************/
    
    list< pair<int,int> > l4;
    int p4[][2] = {{-1,3}, {0,0}, {1,-2}, {1,2}, {1,2}, {2,3}, {3,-1}, {8,10}};
    
    for(int i = 0; i < 7; ++ i ) {
        l4.push_back( pair<int,int>( p4[i][0],p4[i][1] )) ;
	}
	
	cout << "pre:     ";
	for (auto it = l4.begin(); it !=l4.end(); ++ it ) {
         cout << "(" << it->first <<"," << it->second << ") ";
	}
	cout << endl;
	
    selectionsort(l4);
    //swap_cnt = selectionsort(l4);
	
	cout << "post:    ";
	for (auto it = l4.begin(); it !=l4.end(); ++ it ) {
     cout << "(" << it->first <<"," << it->second << ") ";
	}
	cout << endl;
	
	//cout << "move = " << swap_cnt*3 << endl;    
    
    
 
 
    /*******************************
    * test case 5 selectionsort stability
    * The first(earlier) 4 swaps place with 1 thus 
    * putting it after the second(latter) 4
    *******************************/  
    
    cout << "selectionsort stability test" << endl;

    
    list<int> l5;
    int p5 [] ={4,2,3,4,1};
	
	
	for(int i = 0; i < 5; ++ i ) {
        l5.push_back (p5[i]);
	}
	
	
	cout << "pre:     ";
	for (auto it = l5.begin(); it !=l5.end(); ++ it ) {
         cout << *it << " " ;
	}
	cout << endl;
    
    selectionsort(l5);
    //int swap_cnt = selectionsort(l5);

    cout << "post:    ";
	for (auto it = l5.begin(); it !=l5.end(); ++ it ) {
         cout << *it << " " ;
	}
	cout << endl;
    

    return 0;
}